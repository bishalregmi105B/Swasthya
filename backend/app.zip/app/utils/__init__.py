"""
Swasthya Backend Utilities
"""
